/* Decorative motion: stationary on touch/narrow/reduced-motion screens;
   desktop work runs only while its element and document are visible. */
(()=>{'use strict';
 const light=matchMedia('(max-width: 1100px), (pointer: coarse), (prefers-reduced-motion: reduce)');
 const listeners=new Set();
 const automatic=()=>!light.matches;
 const subscribe=fn=>{listeners.add(fn);return ()=>listeners.delete(fn)};
 const sync=()=>listeners.forEach(fn=>fn());
 light.addEventListener('change',sync);
 document.addEventListener('visibilitychange',sync);
 function watch(elements,draw){
  const targets=(Array.isArray(elements)?elements:[elements]).filter(Boolean);
  const visible=new Set();let id=0,previous=0;
  const enabled=()=>automatic()&&!document.hidden&&visible.size>0;
  function frame(now){id=0;if(!enabled())return;const delta=previous?Math.min(80,now-previous):0;previous=now;draw(now,delta);if(enabled())id=requestAnimationFrame(frame)}
  function refresh(){if(enabled()){if(!id){previous=0;id=requestAnimationFrame(frame)}}else{cancelAnimationFrame(id);id=0;previous=0}}
  const observer='IntersectionObserver' in window?new IntersectionObserver(entries=>{entries.forEach(e=>e.isIntersecting?visible.add(e.target):visible.delete(e.target));refresh()}):null;
  targets.forEach(el=>{if(observer)observer.observe(el);else visible.add(el)});
  const unsubscribe=subscribe(refresh);refresh();
  return ()=>{cancelAnimationFrame(id);observer?.disconnect();unsubscribe()};
 }
 window.AIMSMotion={automatic,subscribe,watch};
})();
