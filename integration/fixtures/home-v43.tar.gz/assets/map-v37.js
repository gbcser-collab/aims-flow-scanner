/* One geographic projection and one owner for the public route preview. */
(()=>{'use strict';
const data=window.AIMSMapDataV37,old=document.querySelector('.hero .control');if(!data||!old)return;
const ns='http://www.w3.org/2000/svg',codes=['HU','AT','DE','IT','CH','LI','BE','NL','LU','SK','PL','CZ','RO','DK','LT','GB'];
const names={hu:['Magyarország','Ausztria','Németország','Olaszország','Svájc','Liechtenstein','Belgium','Hollandia','Luxemburg','Szlovákia','Lengyelország','Csehország','Románia','Dánia','Litvánia','Egyesült Királyság'],en:['Hungary','Austria','Germany','Italy','Switzerland','Liechtenstein','Belgium','Netherlands','Luxembourg','Slovakia','Poland','Czechia','Romania','Denmark','Lithuania','United Kingdom'],de:['Ungarn','Österreich','Deutschland','Italien','Schweiz','Liechtenstein','Belgien','Niederlande','Luxemburg','Slowakei','Polen','Tschechien','Rumänien','Dänemark','Litauen','Vereinigtes Königreich']};
const copy={hu:{eyebrow:'EURÓPAI FUVAROZÁS',title:'Merre indul a következő fuvar?',from:'Induló ország',to:'Célország',swap:'Országok felcserélése',quote:'Fuvarajánlatot kérek',note:'Szemléltető reláció · nem közúti útvonalterv',domestic:'Belföldi fuvar',map:'Európai fuvarozási relációk'},en:{eyebrow:'EUROPEAN TRANSPORT',title:'Where is your next shipment going?',from:'Origin country',to:'Destination country',swap:'Swap countries',quote:'Request a transport quote',note:'Illustrative connection · not a road itinerary',domestic:'Domestic transport',map:'European transport connections'},de:{eyebrow:'EUROPÄISCHE TRANSPORTE',title:'Wohin geht Ihr nächster Transport?',from:'Abholland',to:'Zielland',swap:'Länder tauschen',quote:'Transportangebot anfragen',note:'Schematische Verbindung · keine Straßenroute',domestic:'Inlandstransport',map:'Europäische Transportverbindungen'}};
const lang=()=>names[document.documentElement.lang]?document.documentElement.lang:'hu';
const country=code=>names[lang()][codes.indexOf(code)]||code;
const flags={};old.querySelectorAll('[data-country]').forEach(el=>{const src=el.querySelector('img')?.getAttribute('src');if(src)flags[el.dataset.country]=src});
let from='HU',to='DE';
const root=document.createElement('section');root.id='routePlannerV37';root.className='control route-planner-v37';root.setAttribute('aria-labelledby','routeTitleV37');
root.innerHTML='<header class="route-heading-v37"><p data-map-copy="eyebrow"></p><h2 id="routeTitleV37" data-map-copy="title"></h2></header><div class="route-chart-v37"></div><p class="route-note-v37" data-map-copy="note"></p><div class="route-fields-v37"><label class="route-from-v37" for="routeFromV37"><span data-map-copy="from"></span><div><img alt=""><select id="routeFromV37"></select></div></label><button type="button" id="routeSwapV37" data-map-copy="swap"></button><label class="route-to-v37" for="routeToV37"><span data-map-copy="to"></span><div><img alt=""><select id="routeToV37"></select></div></label></div><p id="routeSummaryV37" role="status" aria-live="polite"></p><button type="button" id="routeQuoteV37" data-map-copy="quote"></button>';
old.before(root);
// Old translation wrappers still reference their control IDs. Keep only their
// inert compatibility DOM; its observers and animation stop when it is hidden.
const legacy=document.createElement('div');legacy.hidden=true;legacy.inert=true;legacy.id='routeLegacyV37';legacy.style.setProperty('display','none','important');document.body.append(legacy);legacy.append(old);
const make=(tag,attrs={})=>{const el=document.createElementNS(ns,tag);Object.entries(attrs).forEach(([k,v])=>el.setAttribute(k,v));return el};
const svg=make('svg',{viewBox:data.viewBox,preserveAspectRatio:'xMidYMid meet',role:'img','aria-labelledby':'mapTitleV37 mapDescV37'}),title=make('title',{id:'mapTitleV37'}),desc=make('desc',{id:'mapDescV37'});svg.append(title,desc);
const defs=make('defs'),clip=make('clipPath',{id:'mapClipV37'});clip.append(make('rect',{width:1000,height:820,rx:24}));defs.append(clip);svg.append(defs);
const scene=make('g',{'clip-path':'url(#mapClipV37)'});scene.append(make('rect',{width:1000,height:820,class:'map-water-v37'}));
const land=make('g');data.countries.forEach(c=>{const path=make('path',{d:c.d,class:'map-country-v37'+(c.served?' served':''),'data-map-country':c.code});const t=make('title');t.textContent=c.served?country(c.code):c.name;path.append(t);land.append(path)});scene.append(land);
const route=make('path',{class:'map-line-v37',fill:'none'});scene.append(route);
const vehicles=make('g',{'aria-hidden':'true',class:'map-vehicles-v38'});const cars=[0,1].map(i=>{const g=make('g');g.append(make('path',{d:i?'M-31,-14 H9 V8 H-31 Z M12,-7 H23 L33,3 V8 H12 Z':'M-29,-11 H9 L21,-5 L29,3 V8 H-29 Z',fill:i?'#d8b567':'#f6e2ac',stroke:'#201b13','stroke-width':2.5}),make('path',{d:i?'M16,-4 H22 L27,2 H16 Z':'M10,-7 L19,-3 L23,1 H10 Z',fill:'#25343b'}),make('circle',{cx:-19,cy:9,r:6,fill:'#101418',stroke:'#e9cf91','stroke-width':2}),make('circle',{cx:20,cy:9,r:6,fill:'#101418',stroke:'#e9cf91','stroke-width':2}));vehicles.append(g);return g});scene.append(vehicles);
let curve=null,phase=0;
function drawVehicles(){if(!curve)return;const {ax,ay,bx,by,cx,cy}=curve;cars.forEach((car,i)=>{const t=.14+((phase+i*.5)%1)*.72,u=1-t,x=u*u*ax+2*u*t*cx+t*t*bx,y=u*u*ay+2*u*t*cy+t*t*by;car.setAttribute('transform',`translate(${x.toFixed(2)} ${(y-8).toFixed(2)}) scale(${bx>=ax?1:-1} 1)`)});}
const nodes=make('g');codes.forEach(code=>{const [x,y]=data.points[code],[tx,ty]=data.labels[code],g=make('g',{'data-map-node':code,class:'map-node-v37'});g.append(make('path',{d:`M${x},${y} L${tx},${ty}`,class:'map-label-leader-v37'}),make('circle',{cx:x,cy:y,r:5,class:'map-dot-v37'}));const text=make('text',{x:tx,y:ty,'text-anchor':'middle','dominant-baseline':'central',class:'map-code-v37'});text.textContent=code;g.append(text);nodes.append(g)});scene.append(nodes);svg.append(scene);root.querySelector('.route-chart-v37').append(svg);
const fromSelect=root.querySelector('#routeFromV37'),toSelect=root.querySelector('#routeToV37');
function mode(){return from===to?'domestic':from==='HU'?'export':to==='HU'?'import':'international'}
function snapshot(){return {from,to,fromName:country(from),toName:country(to),mode:mode()}}
function syncLegacy(){const a=document.getElementById('routeFromV6'),b=document.getElementById('routeToV6'),d=document.getElementById('directionV7');if(a)a.value=from;if(b)b.value=to;if(d)d.value=mode();}
function render(){
 const c=copy[lang()],[ax,ay]=data.points[from],[bx,by]=data.points[to];
 fromSelect.value=from;toSelect.value=to;
 for(const [sel,code] of [[fromSelect,from],[toSelect,to]]){const image=sel.previousElementSibling;if(flags[code])image.src=flags[code];image.hidden=!flags[code];}
 root.querySelectorAll('[data-map-country]').forEach(p=>{const code=p.dataset.mapCountry;p.classList.toggle('selected',code===from||code===to);if(codes.includes(code))p.querySelector('title').textContent=country(code)});
 root.querySelectorAll('[data-map-node]').forEach(g=>{const code=g.dataset.mapNode;g.classList.toggle('selected',code===from||code===to);g.classList.toggle('origin',code===from)});
 const dx=bx-ax,dy=by-ay,bend=Math.min(80,Math.hypot(dx,dy)*.19);
 curve={ax,ay,bx,by,cx:(ax+bx)/2,cy:(ay+by)/2-bend};vehicles.setAttribute('display',from===to?'none':'inline');drawVehicles();
 route.setAttribute('d',from===to?'':`M${ax},${ay} Q${(ax+bx)/2},${(ay+by)/2-bend} ${bx},${by}`);
 const summary=from===to?`${c.domestic}: ${country(from)}`:`${country(from)} → ${country(to)}`;
 root.querySelector('#routeSummaryV37').textContent=summary;title.textContent=c.map;desc.textContent=summary+'. '+c.note;
 syncLegacy();
}
function translate(){const c=copy[lang()];root.querySelectorAll('[data-map-copy]').forEach(el=>el.textContent=c[el.dataset.mapCopy]);for(const sel of [fromSelect,toSelect])sel.replaceChildren(...codes.map(code=>{const o=document.createElement('option');o.value=code;o.textContent=country(code);return o}));render();}
fromSelect.addEventListener('change',()=>{from=fromSelect.value;render()});toSelect.addEventListener('change',()=>{to=toSelect.value;render()});root.querySelector('#routeSwapV37').addEventListener('click',()=>{[from,to]=[to,from];render()});
window.AIMSRouteV37={get:snapshot,set:(a,b)=>{if(codes.includes(a)&&codes.includes(b)){from=a;to=b;render()}}};
// Explicit preset clicks may change the public route; legacy redraws may not.
window.addEventListener('click',e=>{const button=e.target.closest('.practice-card-v9 button'),card=button?.closest('.practice-card-v9');if(!card||!codes.includes(card.dataset.route))return;e.preventDefault();e.stopImmediatePropagation();const code=card.dataset.route;window.AIMSRouteV37.set(card.dataset.dir==='import'?code:'HU',card.dataset.dir==='import'?'HU':code);root.scrollIntoView({behavior:'auto',block:'center'})},true);
window.AIMSMotion?.watch(root,(_now,dt)=>{phase=(phase+dt/18000)%1;drawVehicles()});
new MutationObserver(translate).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});translate();
})();
