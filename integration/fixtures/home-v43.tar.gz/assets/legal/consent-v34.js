/* AIMS consent, policy 2026-10-21-v34. No optional request is made by this file. */
(function () {
  'use strict';
  const KEY = 'aims_consent_v2', VERSION = '2026-10-21-v34';
  const MAX_AGE = 180 * 24 * 60 * 60 * 1000;
  const root = new URL('../../', document.currentScript.src);
  let memory = null, storageOK = true, active = null, expiryTimer;
  const valid = v => !!v && v.policyVersion === VERSION && Number.isFinite(v.savedAt) &&
    v.savedAt <= Date.now() && Date.now() - v.savedAt < MAX_AGE &&
    v.necessary === true && typeof v.functional === 'boolean' && typeof v.analytics === 'boolean';
  function get() {
    let v = memory;
    if (storageOK) {
      try { v = JSON.parse(localStorage.getItem(KEY) || 'null'); }
      catch (_) { storageOK = false; }
    }
    if (!valid(v)) {
      memory = null;
      try { localStorage.removeItem(KEY); } catch (_) { storageOK = false; }
      return null;
    }
    return v;
  }
  function schedule(v) {
    clearTimeout(expiryTimer);
    if (v) expiryTimer = setTimeout(check, Math.min(2147483647, Math.max(1000, v.savedAt + MAX_AGE - Date.now())));
  }
  function notify(v) {
    const googleActive = !!document.querySelector('script[src*="maps.googleapis.com"],iframe[src*="google.com/maps"],iframe[src*="maps.google"]');
    const revokeGoogle = active?.functional && !v?.functional && googleActive;
    active = v; schedule(v);
    window.dispatchEvent(new CustomEvent('aims:consent-changed', { detail: v || {necessary:true,functional:false,analytics:false} }));
    if (revokeGoogle) {
      document.querySelectorAll('iframe[src*="google.com/maps"],iframe[src*="maps.google"]').forEach(f => f.removeAttribute('src'));
      // Reload unloads the previously authorized third-party script and its timers.
      location.reload();
    }
  }
  function save(p, source) {
    const v = {policyVersion:VERSION,savedAt:Date.now(),necessary:true,functional:p.functional === true,analytics:p.analytics === true,marketing:false,source:source || 'settings'};
    memory = v;
    try { localStorage.setItem(KEY, JSON.stringify(v)); storageOK = true; } catch (_) { storageOK = false; }
    notify(v); return v;
  }
  function reset() {
    memory = null; try { localStorage.removeItem(KEY); } catch (_) {}
    notify(null); window.dispatchEvent(new Event('aims:consent-reset'));
  }
  function check() { const v = get(); if (JSON.stringify(v) !== JSON.stringify(active)) notify(v); else schedule(v); }
  active = get(); schedule(active);
  window.AIMSConsent = {get,save,reset,version:VERSION,has:c=>c==='necessary'||(['functional','analytics'].includes(c)&&get()?.[c]===true),open:()=>{}};
  window.addEventListener('storage', e => { if (e.key === KEY || e.key === null) check(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
  const copy = {
    hu:{title:'Te döntesz a sütikről',intro:'A szükséges tároláson túl csak az engedélyeddel indulnak el a főoldal Google-térképei és saját statisztikái. Az irányítószám-javaslatok a saját tárhelyünkről érkeznek. Marketingkövetést nem használunk.',reject:'Elutasítom',accept:'Elfogadom',settings:'Sütibeállítások',save:'Választás mentése',close:'Bezárás',necessary:'Szükséges tárolás · mindig aktív',functional:'Google-térképek',funDetail:'A Google technikai adatokat és a keresett helyet is megkaphatja; EGT-n kívüli adatkezelés is történhet. A címeket enélkül is beírhatod.',analytics:'Saját statisztika',anaDetail:'Csak az esemény neve és a hozzájárulási jelzés kerül továbbításra. Nincs egyedi látogatóazonosító vagy űrlaptartalom.',detail:'A választás 180 napig érvényes, itt bármikor visszavonható. A már betöltött Google-funkció kikapcsolása újratölti az oldalt; előtte mentsd a piszkozatodat.',policy:'Süti- és tárhelytájékoztató',saved:'A választásodat mentettük.'},
    en:{title:'Your cookie choice',intro:'Beyond necessary storage, Google Maps and our own statistics on the home page start only with your consent. Postcode suggestions come from our own server. We do not use marketing tracking.',reject:'Reject',accept:'Accept',settings:'Cookie settings',save:'Save choices',close:'Close',necessary:'Necessary storage · always active',functional:'Google Maps',funDetail:'Google may receive technical data and searched places, with processing outside the EEA. You can still type addresses without this.',analytics:'First-party statistics',anaDetail:'Only the event name and consent indicator are sent. No visitor ID or form contents.',detail:'Your choice lasts 180 days and can be withdrawn here at any time. Disabling a loaded Google feature reloads the page; save your draft first.',policy:'Cookies and storage notice (HU)',saved:'Your choice has been saved.'},
    de:{title:'Ihre Cookie-Auswahl',intro:'Google-Karten und unsere eigene Statistik auf der Startseite starten nur mit Ihrer Einwilligung. Notwendiger Speicher bleibt aktiv. Postleitzahlvorschläge kommen von unserem eigenen Server. Wir verwenden kein Marketing-Tracking.',reject:'Ablehnen',accept:'Akzeptieren',settings:'Cookie-Einstellungen',save:'Auswahl speichern',close:'Schließen',necessary:'Notwendiger Speicher · immer aktiv',functional:'Google-Karten',funDetail:'Google kann technische Daten und gesuchte Orte erhalten; Verarbeitung außerhalb des EWR ist möglich. Adressen können auch ohne diese Funktion eingegeben werden.',analytics:'Eigene Statistik',anaDetail:'Nur Ereignisname und Einwilligungssignal werden übertragen. Keine Besucherkennung oder Formularinhalte.',detail:'Die Auswahl gilt 180 Tage und kann hier jederzeit widerrufen werden. Beim Abschalten einer geladenen Google-Funktion wird die Seite neu geladen; speichern Sie zuerst Ihren Entwurf.',policy:'Cookies und Speicher (HU)',saved:'Ihre Auswahl wurde gespeichert.'}
  };
  function init() {
    // Embedded demos use the parent site's consent UI; no second overlay.
    try { if (window.top !== window.self) {
      document.addEventListener('click', e => {
        if (!e.target.closest('[data-aims-cookie-settings]')) return;
        e.preventDefault();
        try { if (window.parent.AIMSConsent?.open) { window.parent.AIMSConsent.open(); return; } } catch (_) {}
        window.open(new URL('legal/cookies.html', root).href, '_blank', 'noopener');
      });
      return;
    } } catch (_) { return; }
    const host = document.createElement('div'); host.id = 'aims-consent-v34';
    host.innerHTML = `<button type="button" class="ac-pref" data-action="settings" data-copy="settings"></button>
      <section class="ac-banner" aria-labelledby="ac-title" hidden><h2 id="ac-title" data-copy="title"></h2><p data-copy="intro"></p><a class="ac-policy" data-copy="policy"></a><div class="ac-actions"><button type="button" data-action="reject" data-copy="reject"></button><button type="button" data-action="settings" data-copy="settings"></button><button type="button" data-action="accept" data-copy="accept"></button></div></section>
      <dialog class="ac-dialog" aria-labelledby="ac-dialog-title"><h2 id="ac-dialog-title" data-copy="settings"></h2><p data-copy="intro"></p><p class="ac-necessary" data-copy="necessary"></p>
      <label class="ac-option"><input id="ac-functional" type="checkbox"><span><strong data-copy="functional"></strong><small data-copy="funDetail"></small></span></label>
      <label class="ac-option"><input id="ac-analytics" type="checkbox"><span><strong data-copy="analytics"></strong><small data-copy="anaDetail"></small></span></label>
      <p class="ac-detail" data-copy="detail"></p><a class="ac-policy" data-copy="policy"></a><div class="ac-actions"><button type="button" data-action="reject" data-copy="reject"></button><button type="button" data-action="save" data-copy="save"></button><button type="button" data-action="close" data-copy="close"></button></div></dialog><span class="ac-sr" role="status" aria-live="polite"></span>`;
    document.body.appendChild(host);
    const dialog = host.querySelector('dialog'), banner = host.querySelector('.ac-banner'), status = host.querySelector('[role="status"]');
    const functional = host.querySelector('#ac-functional'), analytics = host.querySelector('#ac-analytics');
    let lastFocus;
    const language = () => copy[document.documentElement.lang] || copy.hu;
    function translate() { const c = language(); host.querySelectorAll('[data-copy]').forEach(el => el.textContent = c[el.dataset.copy]); }
    host.querySelectorAll('.ac-policy').forEach(a => a.href = new URL('legal/cookies.html', root).href);
    function sync() { banner.hidden = !!get(); }
    function open() {
      lastFocus = document.activeElement; const v = get();
      functional.checked = !!v?.functional; analytics.checked = !!v?.analytics;
      if (!dialog.open) dialog.showModal();
    }
    function close() { dialog.close(); lastFocus?.focus(); }
    window.AIMSConsent.open = open;
    document.addEventListener('click', e => {
      const external = e.target.closest('[data-aims-cookie-settings]');
      if (external) { e.preventDefault(); open(); return; }
      const b = e.target.closest('#aims-consent-v34 [data-action]'); if (!b) return;
      const a = b.dataset.action;
      if (a === 'settings') return open();
      if (a === 'close') return close();
      if (['save','accept','reject'].includes(a)) {
        save({functional:a==='accept'||(a==='save'&&functional.checked),analytics:a==='accept'||(a==='save'&&analytics.checked)},a);
        if (dialog.open) close(); sync(); status.textContent = language().saved;
      }
    });
    dialog.addEventListener('cancel', () => { lastFocus?.focus(); });
    window.addEventListener('aims:consent-changed', sync);
    new MutationObserver(translate).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    translate(); sync();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
