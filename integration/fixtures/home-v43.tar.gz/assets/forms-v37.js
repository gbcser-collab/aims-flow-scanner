/* Shared submission owner: validate, prevent concurrent requests and retain failed drafts. */
(()=>{'use strict';
const endpoint=document.currentScript.dataset.endpoint||'send.php';
const forms={'lead-form':['start','AIMS START','form-status'],quoteForm:['quote','Fuvarajánlat','quoteStateV8'],partnerFormV8:['partner','Fuvarozói együttműködés','pfStateV8'],digitalFormV28:['digital','AIMS WEBLAB','digitalStateV28'],smartFormV19:['smart','AIMS SMART','smartStateV19'],startFormV46:['start','AIMS START','startStateV46'],flowFormV35:['flow','AIMS FLOW','flowStatusV35'],leadForm:['digital','AIMS WEBLAB','weblabStatusV37']};
const copy={hu:{sending:'Küldés folyamatban…',success:'Az ajánlatkérést sikeresen elküldtük. Hamarosan jelentkezünk.',failure:'A küldés nem sikerült. Az adataid megmaradtak; próbáld újra, vagy küldd el e-mailben.',uncertain:'Nem érkezett visszaigazolás. Az adataid megmaradtak. Ellenőrizd a megkeresés állapotát e-mailben, mielőtt újra elküldöd.',email:'E-mail megnyitása',long:'Az üzenet túl hosszú. Kérjük, rövidítsd a leírást.'},en:{sending:'Sending…',success:'Your enquiry has been sent. We will contact you shortly.',failure:'Sending failed. Your details are preserved. Please retry or send by email.',uncertain:'No confirmation received. Your details are preserved. Check the enquiry status by email before sending again.',email:'Open email',long:'The message is too long. Please shorten the description.'},de:{sending:'Wird gesendet…',success:'Ihre Anfrage wurde gesendet. Wir melden uns bei Ihnen.',failure:'Senden fehlgeschlagen. Ihre Angaben bleiben erhalten. Bitte erneut versuchen oder per E-Mail senden.',uncertain:'Keine Bestätigung erhalten. Ihre Angaben bleiben erhalten. Bitte den Anfragestatus per E-Mail prüfen, bevor Sie erneut senden.',email:'E-Mail öffnen',long:'Die Nachricht ist zu lang. Bitte kürzen Sie die Beschreibung.'}};
const pending=new WeakSet();
function value(el){return el.tagName==='SELECT'?[...el.selectedOptions].map(o=>o.textContent.trim()).join(', '):el.value.trim()}
function payload(form,def,language){
 const title=({en:{quote:'Transport quote',partner:'Carrier cooperation'},de:{quote:'Transportangebot',partner:'Zusammenarbeit als Frachtführer'}}[language]?.[def[0]])||def[1];
 const lines=[title];
 for(const el of form.querySelectorAll('input,select,textarea')){
  if(el.disabled||el.name==='website'||['hidden','submit','button','reset'].includes(el.type)||(['checkbox','radio'].includes(el.type)&&!el.checked))continue;
  const v=value(el);if(!v)continue;
  const label=[...(el.labels||[])].map(l=>{const text=l.cloneNode(true);text.querySelectorAll('input,select,textarea,button').forEach(x=>x.remove());return text.textContent.replace(/\s+/g,' ').trim()}).join(' ')||el.getAttribute('aria-label')||(el.getAttribute('aria-labelledby')||'').split(/\s+/).map(id=>document.getElementById(id)?.textContent||'').join(' ').trim()||el.placeholder||el.name||el.id;
  lines.push(label+': '+v);
 }
 return {kind:def[0],subject:title+({hu:' – webes megkeresés',en:' – website enquiry',de:' – Website-Anfrage'}[language]),body:lines.join('\n\n'),email:form.querySelector('[type=email]')?.value.trim()||'',website:form.querySelector('[name=website]')?.value||'',language};
}
window.addEventListener('submit',async e=>{
 const form=e.target,def=forms[form.id];if(!def)return;
 e.preventDefault();e.stopImmediatePropagation();if(pending.has(form)||!form.reportValidity())return;
 const language=copy[document.documentElement.lang]?document.documentElement.lang:'hu',c=copy[language],data=payload(form,def,language);
 let status=document.getElementById(def[2]);if(!status){status=document.createElement('p');status.id=def[2];form.append(status)}
 status.classList.add('form-status-v37');status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.style.cssText='display:block;grid-column:1/-1;white-space:normal;overflow-wrap:anywhere;line-height:1.6';
 let fallback=form.querySelector('[data-fallback-v37]');if(!fallback){fallback=document.createElement('a');fallback.dataset.fallbackV37='';fallback.className='btn';fallback.style.cssText='grid-column:1/-1;min-height:44px;align-items:center;justify-content:center';form.append(fallback)}
 fallback.hidden=true;fallback.style.display='none';
 document.getElementById('flowFallbackV35')?.setAttribute('hidden','');
 if(new TextEncoder().encode(data.body).length>12000){status.textContent=c.long;return}
 fallback.href='mailto:office@logistic-aims.hu?subject='+encodeURIComponent(data.subject)+'&body='+encodeURIComponent(data.body);fallback.textContent=c.email;
 const buttons=[...form.querySelectorAll('button[type=submit],input[type=submit]')],disabled=buttons.map(b=>b.disabled);
 pending.add(form);form.setAttribute('aria-busy','true');buttons.forEach(b=>b.disabled=true);status.textContent=c.sending;
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),20000);
 try{
  const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(data),signal:controller.signal});
  const result=await response.json();if(!response.ok||result.ok!==true)throw new Error('send');
  status.textContent=c.success;
 }catch(error){status.textContent=error.name==='AbortError'?c.uncertain:c.failure;fallback.hidden=false;fallback.style.display='inline-flex'}
 finally{clearTimeout(timer);pending.delete(form);form.removeAttribute('aria-busy');buttons.forEach((b,i)=>b.disabled=disabled[i])}
},true);
})();
