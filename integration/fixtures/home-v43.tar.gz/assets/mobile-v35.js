/* Single owner for service selection; existing forms keep their submit handlers. */
(()=>{
'use strict';
const $=s=>document.querySelector(s),$$=s=>Array.from(document.querySelectorAll(s));
const copy={
 hu:{quote:'Ajánlatot kérek',request:'Ajánlatkérés',call:'Hívás',pick:'Miben segíthetünk?',hint:'Válassz szolgáltatást. Az ajánlatkérő rögtön alatta jelenik meg.',transport:'Fuvarajánlat kérése',name:'Kapcsolattartó neve',email:'E-mail-cím',phone:'Telefonszám (nem kötelező)',company:'Cégnév (nem kötelező)',vehicles:'Járművek száma (nem kötelező)',goal:'Mire szeretnéd használni a FLOW-t? (nem kötelező)',send:'FLOW-ajánlatkérés elküldése',note:'Add meg az elérhetőségedet; egyeztetünk a járművekről, a nyomkövetésről és a FLOW használatáról.',privacy:'Az adatokat az ajánlatkérés megválaszolására használjuk. A megkeresés nem jelent megrendelést vagy marketingfeliratkozást.',policy:'Adatkezelés',terms:'ÁSZF',sending:'Küldés folyamatban…',success:'Megkaptuk a FLOW-ajánlatkérésedet. Hamarosan jelentkezünk.',failure:'A küldés nem sikerült. Az adataid megmaradtak; próbáld újra, vagy küldd el e-mailben.',emailSend:'Elküldöm e-mailben',from:'Indulás',to:'Érkezés'},
 en:{quote:'Request a quote',request:'Request a quote',call:'Call',pick:'How can we help?',hint:'Choose a service. Its enquiry form appears directly below.',transport:'Transport quote',name:'Contact name',email:'Email address',phone:'Phone (optional)',company:'Company (optional)',vehicles:'Number of vehicles (optional)',goal:'What would you use FLOW for? (optional)',send:'Send FLOW enquiry',note:'Leave your contact details so we can discuss vehicles, tracking and FLOW.',privacy:'We use your details to answer your enquiry. This is not an order or a marketing subscription.',policy:'Privacy',terms:'Terms',sending:'Sending…',success:'Your FLOW enquiry has been received. We will contact you shortly.',failure:'Sending failed. Your details are preserved; retry or send by email.',emailSend:'Send by email',from:'Origin',to:'Destination'},
 de:{quote:'Angebot anfragen',request:'Angebot anfragen',call:'Anrufen',pick:'Wie können wir helfen?',hint:'Wählen Sie einen Service. Das Anfrageformular erscheint direkt darunter.',transport:'Transportangebot',name:'Ansprechpartner',email:'E-Mail-Adresse',phone:'Telefon (optional)',company:'Unternehmen (optional)',vehicles:'Anzahl der Fahrzeuge (optional)',goal:'Wofür möchten Sie FLOW nutzen? (optional)',send:'FLOW-Anfrage senden',note:'Hinterlassen Sie Ihre Kontaktdaten. Wir besprechen Fahrzeuge, Tracking und FLOW.',privacy:'Wir verwenden Ihre Daten zur Beantwortung der Anfrage. Dies ist keine Bestellung oder Marketinganmeldung.',policy:'Datenschutz',terms:'AGB',sending:'Wird gesendet…',success:'Ihre FLOW-Anfrage ist eingegangen. Wir melden uns bei Ihnen.',failure:'Senden fehlgeschlagen. Ihre Angaben bleiben erhalten. Bitte erneut versuchen oder per E-Mail senden.',emailSend:'Per E-Mail senden',from:'Abholung',to:'Ziel'}
};
const lang=()=>copy[document.documentElement.lang]?document.documentElement.lang:'hu';
const defs={client:{name:'Logistic-A.I.M.S.',panel:'quoteCardV24'},flow:{name:'AIMS FLOW',panel:'flowCardV35'},smart:{name:'AIMS SMART',panel:'smartCardV19'},digital:{name:'AIMS WEBLAB',panel:'digitalCardV28'},start:{name:'AIMS START',panel:'startCardV46'},partner:{name:'Fuvarozópartner',panel:'partnerCardV8'}};
const grid=$('#contactGridV8');if(!grid)return;
const flow=document.createElement('div');flow.id='flowCardV35';flow.className='card quote-card';
flow.innerHTML=`<div class="quote-head"><h3 tabindex="-1">AIMS FLOW</h3></div><p data-v35="note"></p><form id="flowFormV35" class="flow-form-v35"><label class="flow-trap-v35" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label><label><span data-v35="name"></span><input name="name" autocomplete="name" maxlength="120" required></label><label><span data-v35="email"></span><input name="email" type="email" autocomplete="email" maxlength="254" required></label><label><span data-v35="company"></span><input name="company" autocomplete="organization" maxlength="180"></label><label><span data-v35="phone"></span><input name="phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="40"></label><label class="full"><span data-v35="vehicles"></span><input name="vehicles" type="number" inputmode="numeric" min="1" max="100000"></label><label class="full"><span data-v35="goal"></span><textarea name="goal" maxlength="4000"></textarea></label><p class="aims-form-notice-v34 full"><span data-v35="privacy"></span> <a href="legal/privacy.html" target="_blank" rel="noopener" data-v35="policy"></a> · <a href="legal/terms.html" target="_blank" rel="noopener" data-v35="terms"></a></p><button class="btn primary full" type="submit" data-v35="send"></button><p id="flowStatusV35" class="full" role="status" aria-live="polite"></p><a id="flowFallbackV35" class="btn full" hidden data-v35="emailSend"></a></form>`;
grid.append(flow);
Object.entries(defs).forEach(([key,d])=>{const el=document.getElementById(d.panel);if(!el)return;el.dataset.quotePanel=key;const h=el.querySelector('h3');if(h)h.tabIndex=-1;});
const picker=document.createElement('div');picker.className='quote-picker-v35';picker.id='servicePickerV35';
picker.innerHTML='<h3 data-v35="pick"></h3><p data-v35="hint"></p><div class="quote-options-v35" role="group"></div>';
for(const key of ['client','flow','smart','digital','start']){const b=document.createElement('button');b.type='button';b.dataset.quoteV35=key;b.setAttribute('aria-controls',defs[key].panel);b.innerHTML='<strong></strong><span></span>';b.querySelector('strong').textContent=defs[key].name;picker.querySelector('.quote-options-v35').append(b);}
$('#audienceSwitchV8')?.replaceWith(picker);
let selected='client';
function closeMenu(){const menu=$('#menu');if(menu?.getAttribute('aria-expanded')==='true')menu.click();}
function activate(key,scroll=true){
 if(!defs[key])key='client';selected=key;grid.dataset.quoteService=key;
 grid.classList.remove('partner-mode-v8','digital-mode-v28','start-mode-v46','smart-mode-v19');
 $$('[data-quote-panel]').forEach(p=>{const active=p.dataset.quotePanel===key;p.classList.toggle('quote-active-v35',active);p.hidden=!active;});
 picker.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.quoteV35===key)));
 if(scroll){closeMenu();const panel=document.getElementById(defs[key].panel);panel.querySelector('h3')?.focus({preventScroll:true});panel.scrollIntoView({block:'start',behavior:'auto'});history.replaceState(null,'','#quote-'+key);}
}
function linkFor(el,key){el.dataset.quoteV35=key;el.setAttribute('href','#quote-'+key);el.removeAttribute('target');}
$$('[data-open-audience-v28],[data-quote-dest-v39]').forEach(el=>{const key=el.dataset.openAudienceV28||el.dataset.quoteDestV39;if(defs[key])linkFor(el,key);});
$$('#heroQuoteV24,.transport-cta-v27,.hero-actions a[href="#contact"],.hero-door-v47[href="#contact"],#services a[href="#contact"],.practice-card-v9 a[href="#contact"]').forEach(el=>linkFor(el,'client'));
for(const [product,key] of [['flow','flow'],['smart','smart'],['start','start'],['weblab','digital']]){
 const card=$('#brands .aims-eco-card-v70.'+product);if(!card)continue;
 // The original product link remains available; the quote action sits above its card overlay.
 const a=document.createElement('a');a.className='quote-card-action-v35';a.dataset.v35='quote';linkFor(a,key);card.append(a);
}
// Existing section quote buttons are enquiry actions, not product-page navigation.
$$('#flow .aims-product-actions-v70 a,#smart .aims-product-actions-v70 a,#start .start-cta-v35,#digital .digital-offer-v26 a.digital-btn-v26').forEach(a=>{
 const key=a.closest('#flow')?'flow':a.closest('#smart')?'smart':a.closest('#start')?'start':'digital';linkFor(a,key);
});
const dock=$('.mobile-dock');if(dock){dock.innerHTML='<a class="dock-quote-v35" href="#quote-client" data-quote-v35="client"><b aria-hidden="true">＋</b><span data-v35="request"></span></a><a class="dock-call-v40" href="tel:+36705906861"><b aria-hidden="true">☎</b><span data-v35="call"></span></a>';}
// A direct quote action is available even if the old mobile menu omitted it.
const nav=$('#mobile');if(nav&&!nav.querySelector('[data-quote-v35="client"]')){const a=document.createElement('a');a.className='quote-card-action-v35';a.dataset.v35='request';linkFor(a,'client');nav.prepend(a);}
if(nav){
 const languages=document.createElement('div');languages.className='mobile-langs-v35';languages.setAttribute('role','group');languages.setAttribute('aria-label','Nyelv / Language / Sprache');
 for(const code of ['hu','en','de']){const b=document.createElement('button');b.type='button';b.textContent=code.toUpperCase();b.addEventListener('click',()=>{$('.header-inner .lang [data-lang="'+code+'"]')?.click();});languages.append(b);}nav.append(languages);
 const syncMenu=()=>document.body.classList.toggle('menu-open-v35',nav.classList.contains('open'));new MutationObserver(syncMenu).observe(nav,{attributes:true,attributeFilter:['class']});syncMenu();
}
window.addEventListener('click',e=>{
 const route=e.target.closest('#routeQuoteV6,#routeQuoteV37');const action=e.target.closest('[data-quote-v35]');const ticker=e.target.closest('[data-v34-action]');const tickerKey={ac:'client',ap:'partner',ad:'digital',as:'start'}[ticker?.dataset.v34Action];if(!route&&!action&&!tickerKey)return;
 if(e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;
 e.preventDefault();e.stopImmediatePropagation();
 if(route){for(const [id,sel] of [['origin','#routeFromV6'],['destination','#routeToV6']]){const input=document.getElementById(id),select=$(sel);if(input&&select){input.value=select.selectedOptions[0].textContent.replace(/^[A-Z]{2}\s*[—–-]\s*/,'');input.dispatchEvent(new Event('input',{bubbles:true}));}}const selectedRoute=window.AIMSRouteV37?.get();if(selectedRoute){for(const [id,code] of [['originCountryV38',selectedRoute.from],['destinationCountryV38',selectedRoute.to]]){const country=document.getElementById(id);if(country)country.value=code;}const r=$('#route');if(r)r.value=selectedRoute.from+' → '+selectedRoute.to;for(const [id,key] of [['origin','fromName'],['destination','toName']]){const input=document.getElementById(id);if(input)input.value=selectedRoute[key];}const a=$('#rpFromV9'),b=$('#rpToV9'),t=$('#rpTitleV9'),m=$('#rpModeV9');if(a)a.textContent=selectedRoute.from;if(b)b.textContent=selectedRoute.to;if(t)t.textContent=selectedRoute.fromName+' → '+selectedRoute.toName;if(m)m.textContent=({hu:{domestic:'Belföldi',international:'Nemzetközi'},en:{domestic:'Domestic',international:'International'},de:{domestic:'Inland',international:'International'}}[lang()][selectedRoute.mode]||selectedRoute.mode.toUpperCase())+' • '+($('#service')?.selectedOptions[0]?.textContent||'');}activate('client');}
 else activate(tickerKey||action.dataset.quoteV35);
},true);
function hashService(){const m=location.hash.match(/^#quote-(client|flow|smart|digital|start|partner)$/);return m?.[1]||null;}
addEventListener('hashchange',()=>{const key=hashService();if(key)activate(key);});
function translate(){const c=copy[lang()];
 try{const names=new Intl.DisplayNames([lang()],{type:'region'});$$('#routeFromV6 option,#routeToV6 option').forEach(o=>{o.textContent=o.value+' — '+names.of(o.value);});}catch(_){}
 $$('[data-v35]').forEach(el=>{const t=c[el.dataset.v35];if(t)el.textContent=t;});picker.querySelectorAll('button').forEach(b=>b.querySelector('span').textContent=b.dataset.quoteV35==='client'?c.transport:c.quote);picker.querySelector('[role=group]').setAttribute('aria-label',c.pick);syncMap();}
new MutationObserver(translate).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
// Mobile map: country names outside the plotting area; native country selectors remain available.
const map=$('.live-map-v3'),caption=document.createElement('div');caption.className='mobile-map-caption-v35';map?.after(caption);
function syncMap(){if(!map)return;const c=copy[lang()];caption.replaceChildren();for(const [id,label] of [['routeFromV6',c.from],['routeToV6',c.to]]){const sel=document.getElementById(id);if(!sel)continue;const card=document.createElement('div'),small=document.createElement('small'),strong=document.createElement('strong'),name=document.createElement('span');small.textContent=label;name.textContent=sel.selectedOptions[0]?.textContent.replace(/^[A-Z]{2}\s*[—–-]\s*/,'')||sel.value;const flag=map.querySelector('[data-country="'+sel.value+'"] img')?.cloneNode(true);if(flag){flag.alt='';strong.append(flag);}strong.append(name);card.append(small,strong);caption.append(card);}}
const mapMedia=matchMedia('(max-width:900px)');function mapAccessibility(){map?.querySelectorAll('.map-country-label').forEach(e=>{e.tabIndex=mapMedia.matches?-1:0;if(mapMedia.matches)e.setAttribute('aria-hidden','true');else e.removeAttribute('aria-hidden');});}mapMedia.addEventListener('change',mapAccessibility);mapAccessibility();
const info=$('#routeLiveInfoV6');if(info)new MutationObserver(syncMap).observe(info,{childList:true,subtree:true,characterData:true});
// Browser autofill and phone keyboards on all existing enquiry forms.
$$('#contact input').forEach(el=>{if(el.type==='email')el.autocomplete='email';else if(/phone/i.test(el.id)){el.type='tel';el.inputMode='tel';el.autocomplete='tel';}else if(/company/i.test(el.id))el.autocomplete='organization';else if(/name/i.test(el.id)&&el.name!=='website')el.autocomplete='name';});
const form=$('#flowFormV35');let busy=false;
form.addEventListener('submit',async e=>{
 e.preventDefault();if(busy||!form.reportValidity())return;
 const c=copy[lang()],fd=new FormData(form),g=k=>String(fd.get(k)||'').trim();
 const subject='AIMS FLOW-ajánlatkérés',body=['AIMS FLOW',`Kapcsolattartó: ${g('name')}`,`E-mail: ${g('email')}`,`Cégnév: ${g('company')}`,`Telefon: ${g('phone')}`,`Járművek száma: ${g('vehicles')}`,'',g('goal')].join('\n');
 const status=$('#flowStatusV35'),fallback=$('#flowFallbackV35'),button=form.querySelector('[type=submit]');
 fallback.href='mailto:office@logistic-aims.hu?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body);fallback.hidden=true;busy=true;button.disabled=true;status.textContent=c.sending;
 try{const r=await fetch('send.php',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({kind:'flow',subject,body,email:g('email'),website:g('website'),language:lang()})});const result=await r.json();if(!r.ok||!result.ok)throw new Error('send');status.textContent=c.success;form.reset();}
 catch(_){status.textContent=c.failure;fallback.hidden=false;}
 finally{busy=false;button.disabled=false;}
});
activate(hashService()||'client',false);translate();
if(hashService())requestAnimationFrame(()=>activate(hashService()));
})();
